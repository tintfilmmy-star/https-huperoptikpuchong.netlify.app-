HUPER OPTIK TINT PUCHONG / PUCHONG SMART TINTS GARAGE — TRILINGUAL WEBSITE

Included:
- index.html: responsive one-page website in English, Bahasa Malaysia and Simplified Chinese.
- Language selector (EN / BM / 中文), remembers visitor choice in their browser.
- Sections for car tinting, windscreen replacement, insurance claim enquiries, service areas and contact.
- WhatsApp quote/enquiry form (opens WhatsApp; no website database or form storage).

IMPORTANT — verify before publishing:
- The phone/WhatsApp number and address below were carried over from the initial draft and have NOT been independently confirmed by the business owner in this chat:
  018-319 9068
  31G, Jalan OP 1/6, One Puchong Business Park, 47160 Puchong, Selangor
- Confirm exact service coverage, operating hours, brand/dealer wording, packages, warranties and insurance-claim arrangements.
- Replace stock photos with your own workshop, tint installation and completed-vehicle photos for stronger trust and local SEO.
- Add your domain and hosting, then upload index.html to the hosting public folder.

The page uses externally hosted Unsplash images and requires internet access to display them.
