HUPER OPTIK PUCHONG — CMS WEBSITE PACKAGE

This package adds Pages CMS configuration and editable business content to the original website.

IMPORTANT: The site is not live yet. Before publishing, confirm the business address, opening hours, phone number, prices, promotion dates, and all brand/dealer or warranty claims. Replace the placeholder address in content-site.json.

FILES
- index.html: public website
- .pages.yml: Pages CMS editor configuration
- content-site.json: editable business details, homepage text, promotions, tint packages and gallery
- media/images/: uploaded photos go here

UPLOAD TO GITHUB
1. Open https://github.com/huperoptikpuchong/huperoptikpuchong-website
2. Click Add file > Upload files.
3. Extract this ZIP on your computer and upload ALL files and folders inside it. Make sure hidden file .pages.yml is included. If Windows hides dotfiles, enable View > Show > Hidden items or create .pages.yml separately.
4. Commit changes to the main branch.
5. Visit https://app.pagescms.org and sign in with GitHub.
6. Install/authorize the Pages CMS GitHub App for this repository only, if prompted.
7. Select repository huperoptikpuchong/huperoptikpuchong-website and branch main.
8. Open Business details & homepage to edit details, promotions, packages and gallery images.

WHAT CAN BE EDITED IN THIS FIRST CMS VERSION
- Company / brand names, WhatsApp number, display phone, address, opening hours
- Homepage headline and intro
- Promotions (title, details, offer price, expiry, image, show/hide)
- Tint packages (name, description, price, image, show/hide)
- Photo gallery (caption and image)

The original site language selector remains. The CMS content fields in this first version are shared across languages; the pre-existing service and navigation translations remain in the HTML. Full separate editing of every English/BM/Chinese text can be added in a later version.

DEPLOYMENT
The CMS only edits GitHub files; it does not host the public site. Connect this repository to Netlify (or another static host) after uploading. Set the publish directory to the repository root and leave build command blank. Each commit will trigger a new deployment if continuous deployment is enabled.
